import javax.swing.*;
import java.awt.*;
import java.io.*;

public class MovementPanel extends JPanel {
	
	private JTextArea movementArea;
	public MovementPanel(){
		setLayout(new BorderLayout());

		movementArea = new JTextArea(20,40);
		movementArea.setEditable(false);
		add(movementArea, BorderLayout.CENTER);

		/*loadInstructions();*/
	}
}