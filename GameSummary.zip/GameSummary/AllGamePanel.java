import javax.swing.*;
import java.awt.*;
import java.io.*;

public class AllGamePanel extends JPanel {
	
	private JTextArea allGameArea;
	public AllGamePanel(){
		setLayout(new BorderLayout());

		allGameArea = new JTextArea(20,40);
		allGameArea.setEditable(false);
		add(allGameArea, BorderLayout.CENTER);

		/*loadInstructions();*/
	}
}