import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TransitionExample {
    private JFrame frame;
    private JPanel panel1, panel2;
    private CardLayout cardLayout;
    private Timer timer;

    public TransitionExample() {
        frame = new JFrame("Transition Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel1 = new JPanel();
        panel1.setBackground(Color.RED);
        panel1.add(new JButton("OK"));

        panel2 = new JPanel();
        panel2.setBackground(Color.BLUE);

        cardLayout = new CardLayout();
        frame.getContentPane().setLayout(cardLayout);

        frame.getContentPane().add(panel1, "panel1");
        frame.getContentPane().add(panel2, "panel2");

        JButton okButton = (JButton) panel1.getComponent(0);
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startTransition();
            }
        });

        frame.pack();
        frame.setVisible(true);
    }

    private void startTransition() {
        timer = new Timer(10, new ActionListener() {
            int alpha = 255;

            @Override
            public void actionPerformed(ActionEvent e) {
                alpha = Math.max(0, alpha - 10); // Ensure alpha doesn't go below 0
                panel1.setBackground(new Color(255, 0, 0, alpha));
                if (alpha <= 0) {
                    cardLayout.show(frame.getContentPane(), "panel2");
                    timer.stop();
                }
            }
        });
        timer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TransitionExample();
            }
        });
    }
}