import javax.swing.*;
import java.awt.*;

public class Summary extends JFrame{
	private JTabbedPane tabbedPane; 
	public Summary(){
	super("Summary");
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setSize(600,400);

	tabbedPane = new JTabbedPane();
	Container contentPane = getContentPane();
	SummaryPanel summaryPanel = new SummaryPanel();
	MovementPanel movementPanel = new MovementPanel();
	AllGamePanel allGamePanel = new AllGamePanel(); 
  
	contentPane.add(tabbedPane, BorderLayout.CENTER);
  	tabbedPane.addTab("Game Summary", summaryPanel);
	tabbedPane.addTab("All Moves", movementPanel);
	tabbedPane.addTab("All Games", allGamePanel);
	}

	public static void main(String[] args) {
		Summary summary = new Summary();
		summary.setVisible(true);

	}	
}