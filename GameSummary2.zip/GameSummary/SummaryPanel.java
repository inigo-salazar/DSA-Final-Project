import javax.swing.*;
import java.awt.*;
import java.io.*;

public class SummaryPanel extends JPanel {
	
	private JTextArea summaryArea;
	public SummaryPanel(){
		setLayout(new BorderLayout());

		summaryArea = new JTextArea(20,40);
		summaryArea.setEditable(false);
		add(summaryArea, BorderLayout.CENTER);

		/*loadInstructions();*/
	}
}