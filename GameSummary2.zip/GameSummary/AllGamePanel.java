import javax.swing.*;
import java.awt.*;
import java.io.*;

public class AllGamePanel extends JPanel {
	
	private JTextArea allGameArea;
	public AllGamePanel(){
		setLayout(new BorderLayout());

		allGameArea = new JTextArea(20,40);
		allGameArea.setEditable(false);
		add(allGameArea, BorderLayout.CENTER);

		loadInstructions();
	}

		public void loadInstructions(){
		File instructionsFile = new File ("C:/Users/Joaquin/OneDrive/Desktop/School/Code/Java/GameSummary/ChessLogs.txt");

	try {
    //BufferedReader is a form of character stream used when dealing with text files. This reads text file line by line
    BufferedReader reader = new BufferedReader(new FileReader(instructionsFile));

    //StringBuilder is Java object that allows manipulation of string especially used when dealing with series of string manipulations
    StringBuilder sb = new StringBuilder();

    //String variable would hold the text in the file line
    String line;

    //reader.readLine reads and return the characters that composed the text line. When end of file (EOF) is reached, null is returned.
    while ((line = reader.readLine()) != null) {
        sb.append(line).append("\n");
    }

    //Once EOF is reached, get the value of string builder and send it to the component
    allGameArea.setText(sb.toString());

    //Always close the reader after use
    reader.close();
  } catch (IOException ex) {
      JOptionPane.showMessageDialog(this, "Error opening file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
  }	
	}
}